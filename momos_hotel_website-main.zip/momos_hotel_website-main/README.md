# momos_hotel_website
 momos_hotel_website is written in python django,html,css,bootstrap.
